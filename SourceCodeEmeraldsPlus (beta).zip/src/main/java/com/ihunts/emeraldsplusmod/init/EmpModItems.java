
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.ihunts.emeraldsplusmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import com.ihunts.emeraldsplusmod.item.EmeraldIngotItem;
import com.ihunts.emeraldsplusmod.EmpMod;

public class EmpModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, EmpMod.MODID);
	public static final RegistryObject<Item> EMERALD_INGOT = REGISTRY.register("emerald_ingot", () -> new EmeraldIngotItem());
}
